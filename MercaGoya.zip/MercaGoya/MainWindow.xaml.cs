﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MercaGoya
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Producto> listaProductos = new List<Producto>();
        Ticket ticket;
        public MainWindow()
        {
            InitializeComponent();

            CargarProductos();
        }

        void CargarProductos()
        {
            // añadir 4 productos a la colección de productos

            // mostrar la colección Productos en el listbox de Productos

        }

        private void lbProductos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Asignar valor a la propiedad Linea del Ticket y acumular precio en la propiedad Total
        }

        private void botNuevo_Click(object sender, RoutedEventArgs e)
        {
            // instanciaar un nuevo ticket, suscribire eventos e IniciarTicket

        }
        void ticket_nuevoTicket(object sender, EventArgs e)
        {
            //Limpiar listbox Ticket y textbox Entrega

            //Crear Cabecera 

        }

        void ticket_nuevaLinea(object sender, EventArgs e)
        {
            // Añadir Linea al ListBox

        }

        private void botCerrar_Click(object sender, RoutedEventArgs e)
        {
            // Cerrar el ticket mostrando la línea de * y el Total

        }

        private void botCambio_Click(object sender, RoutedEventArgs e)
        {
            // Mostrar cantidad entregada y el cambio

        }
    }

    public class Producto
    {
        // declarar los atributos respetando las especificaciones
    }
    public class Ticket
    {
        // declarar los atributos respetando las especificaciones
    }
}
